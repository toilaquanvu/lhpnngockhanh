<?php 
  const DOMAIN = "https://www.vmquandev.id.vn/public/";
const DB_HOST = "localhost";
const DB_USER = "vmquanvn_quanvm";
const DB_PASS = "rTMw]gBt3Tbr";
const DB_NAME = "vmquanvn_lhpnngockhanh";
<?php
require_once __DIR__ . '/../app/routes/web.php';

new Web();
?>